
//{{BLOCK(img_title)

//======================================================================
//
//	img_title, 240x160@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 38400 = 38912
//
//	Time-stamp: 2022-03-04, 21:59:25
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_IMG_TITLE_H
#define GRIT_IMG_TITLE_H

#define img_titleBitmapLen 38400
extern const unsigned short img_titleBitmap[19200];

#define img_titlePalLen 512
extern const unsigned short img_titlePal[256];

#endif // GRIT_IMG_TITLE_H

//}}BLOCK(img_title)
