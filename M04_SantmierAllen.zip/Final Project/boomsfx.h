// boomsfx sound made by wav2c

extern const unsigned int boomsfx_sampleRate;
extern const unsigned int boomsfx_length;
extern const signed char boomsfx_data[];
