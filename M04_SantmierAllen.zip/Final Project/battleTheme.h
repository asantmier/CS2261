// battleTheme sound made by wav2c

extern const unsigned int battleTheme_sampleRate;
extern const unsigned int battleTheme_length;
extern const signed char battleTheme_data[];
