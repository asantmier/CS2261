~~==~~==~~==~TOMOGATCHI  MINIGAME~==~~==~~==~~

-------------------CONTROLS-------------------
Left & Right arrows - Move Tomogatchi
Start button        - Restart (when prompted)

------------------HOW TO PLAY-----------------
Collect 3 red fruits to grow your Tomogatchi
and win the game! Don't get hit by the falling
spikes or the game will restart!

----------------SPECIAL ~FLAIR~---------------
A small little bit of flair is a finish screen
where you can jump back into the game by
pressing the Start button.