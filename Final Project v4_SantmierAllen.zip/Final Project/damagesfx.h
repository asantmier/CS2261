// damagesfx sound made by wav2c

extern const unsigned int damagesfx_sampleRate;
extern const unsigned int damagesfx_length;
extern const signed char damagesfx_data[];
