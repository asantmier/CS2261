// worldTheme sound made by wav2c

extern const unsigned int worldTheme_sampleRate;
extern const unsigned int worldTheme_length;
extern const signed char worldTheme_data[];
