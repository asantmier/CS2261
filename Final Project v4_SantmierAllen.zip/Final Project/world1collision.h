
//{{BLOCK(world1collision)

//======================================================================
//
//	world1collision, 1024x1024@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 1048576 = 1049088
//
//	Time-stamp: 2022-04-12, 17:29:32
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_WORLD1COLLISION_H
#define GRIT_WORLD1COLLISION_H

#define world1collisionBitmapLen 1048576
extern const unsigned short world1collisionBitmap[524288];

#define world1collisionPalLen 512
extern const unsigned short world1collisionPal[256];

#endif // GRIT_WORLD1COLLISION_H

//}}BLOCK(world1collision)
