#ifndef GAME_H
#define GAME_H

extern int playerHp; // Player health

// Initialize game
void initGame();

#endif