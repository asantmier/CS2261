#include <stdlib.h>
#include "mode0.h"
#include "print.h"
#include "game.h"

int playerHp;

void initGame() {
    playerHp = 100;
}
