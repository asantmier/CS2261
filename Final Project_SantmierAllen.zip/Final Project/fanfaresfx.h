// fanfaresfx sound made by wav2c

extern const unsigned int fanfaresfx_sampleRate;
extern const unsigned int fanfaresfx_length;
extern const signed char fanfaresfx_data[];
