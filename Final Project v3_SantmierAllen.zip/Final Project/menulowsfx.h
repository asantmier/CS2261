// menulowsfx sound made by wav2c

extern const unsigned int menulowsfx_sampleRate;
extern const unsigned int menulowsfx_length;
extern const signed char menulowsfx_data[];
