// menuhighsfx sound made by wav2c

extern const unsigned int menuhighsfx_sampleRate;
extern const unsigned int menuhighsfx_length;
extern const signed char menuhighsfx_data[];
