// bossTheme sound made by wav2c

extern const unsigned int bossTheme_sampleRate;
extern const unsigned int bossTheme_length;
extern const signed char bossTheme_data[];
