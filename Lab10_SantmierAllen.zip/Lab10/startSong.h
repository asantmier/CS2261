// startSong sound made by wav2c

extern const unsigned int startSong_sampleRate;
extern const unsigned int startSong_length;
extern const signed char startSong_data[];
