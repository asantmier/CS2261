// winSong sound made by wav2c

extern const unsigned int winSong_sampleRate;
extern const unsigned int winSong_length;
extern const signed char winSong_data[];
