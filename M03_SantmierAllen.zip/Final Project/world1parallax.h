
//{{BLOCK(world1parallax)

//======================================================================
//
//	world1parallax, 256x512@8, 
//	+ palette 256 entries, not compressed
//	+ 8 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x64 
//	Total size: 512 + 512 + 4096 = 5120
//
//	Time-stamp: 2022-04-11, 20:27:03
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_WORLD1PARALLAX_H
#define GRIT_WORLD1PARALLAX_H

#define world1parallaxTilesLen 512
extern const unsigned short world1parallaxTiles[256];

#define world1parallaxMapLen 4096
extern const unsigned short world1parallaxMap[2048];

#define world1parallaxPalLen 512
extern const unsigned short world1parallaxPal[256];

#endif // GRIT_WORLD1PARALLAX_H

//}}BLOCK(world1parallax)
