
//{{BLOCK(level1_collision)

//======================================================================
//
//	level1_collision, 240x160@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 38400 = 38912
//
//	Time-stamp: 2022-03-19, 13:45:39
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVEL1_COLLISION_H
#define GRIT_LEVEL1_COLLISION_H

#define level1_collisionBitmapLen 38400
extern const unsigned short level1_collisionBitmap[19200];

#define level1_collisionPalLen 512
extern const unsigned short level1_collisionPal[256];

#endif // GRIT_LEVEL1_COLLISION_H

//}}BLOCK(level1_collision)
