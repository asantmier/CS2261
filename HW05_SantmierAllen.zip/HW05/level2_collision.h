
//{{BLOCK(level2_collision)

//======================================================================
//
//	level2_collision, 240x160@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 38400 = 38912
//
//	Time-stamp: 2022-03-18, 14:14:46
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVEL2_COLLISION_H
#define GRIT_LEVEL2_COLLISION_H

#define level2_collisionBitmapLen 38400
extern const unsigned short level2_collisionBitmap[19200];

#define level2_collisionPalLen 512
extern const unsigned short level2_collisionPal[256];

#endif // GRIT_LEVEL2_COLLISION_H

//}}BLOCK(level2_collision)
